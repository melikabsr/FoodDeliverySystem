#include "clienthandler.h"

#include "DatabaseManager.h"
#include <QTextStream>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include "ServerOrder.h"
#include "OrderManager.h"
#include "Food.h"

ClientHandler::ClientHandler(QTcpSocket* socket, QObject* parent)
    : QThread(parent), socket(socket)
{}

void ClientHandler::run()
{
    if (!socket->waitForReadyRead(3000)) {
        socket->close();
        return;
    }

    while (socket->state() == QTcpSocket::ConnectedState) {
        if (!socket->waitForReadyRead(5000)) continue;

        QString msg = QString::fromUtf8(socket->readAll()).trimmed();
        qDebug() << "📨 From client:" << msg;
        processMessage(msg);
    }

    socket->close();
}

void ClientHandler::processMessage(const QString& msg)
{
    QStringList parts = msg.split("|");
    if (parts.isEmpty()) return;

    QString command = parts[0].toUpper();

    if (command == "LOGIN") {
        handleLogin(parts);
    } else if (command == "GET_RESTAURANTS") {
        handleGetRestaurants();
    } else if (command == "GET_MENU") {
        handleGetMenu(parts);
    } else if (command == "ADD_ORDER") {
        handleAddOrder(parts);
    } else if (command == "GET_ORDERS") {
        handleGetOrders(parts);
    } else if (command == "UPDATE_ORDER_STATUS") {
        handleUpdateOrderStatus(parts);
    } else if (command == "GET_ORDERS_BY_RESTAURANT") {
        handleGetOrdersByRestaurant(parts);
    } else {
        socket->write("❓ Unknown command\n");
    }
}
void ClientHandler::handleLogin(const QStringList& parts)
{
    if (parts.size() < 4) {
        socket->write("LOGIN_RESULT|FAILED|MISSING_FIELDS\n");
        return;
    }

    QString u = parts[1].trimmed();
    QString p = parts[2].trimmed();
    QString role = parts[3].trimmed().toUpper();

    qDebug() << "🧪 Login request:" << u << p << role;

    // فقط برای ADMIN محدودیت داریم
    if (role == "ADMIN") {
        if (u == "admin" && p == "admin") {
            username = u;
            socket->write("LOGIN_RESULT|SUCCESS|ADMIN\n");
        } else {
            socket->write("LOGIN_RESULT|FAILED|NOT_ADMIN\n");
        }
        return;
    }

    // برای سایر نقش‌ها ورود آزاد است
    username = u;

    if (role == "RESTAURANT_OWNER") {
        int restaurantId = DatabaseManager::instance().getRestaurantId(u);
        socket->write(QString("LOGIN_RESULT|SUCCESS|RESTAURANT_OWNER|%1\n").arg(restaurantId).toUtf8());
    } else {
        socket->write(QString("LOGIN_RESULT|SUCCESS|%1\n").arg(role).toUtf8());
    }
}


void ClientHandler::handleGetMenu(const QStringList& parts)
{
    if (parts.size() < 2) {
        socket->write("❌ GET_MENU|Missing ID\n");
        return;
    }

    int restId = parts[1].toInt();
    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("SELECT id, name, description, price FROM menu WHERE restaurant_id = ?");
    query.addBindValue(restId);
    query.exec();

    QStringList items;
    while (query.next()) {
        items << QString("%1,%2,%3,%4")
        .arg(query.value(0).toInt())
            .arg(query.value(1).toString())
            .arg(query.value(2).toString())
            .arg(query.value(3).toDouble());
    }

    socket->write(("MENU|" + items.join(";") + "\n").toUtf8());
}

void ClientHandler::handleAddOrder(const QStringList& parts)
{
    if (parts.size() < 4) {
        socket->write("❌ ADD_ORDER|Missing fields\n");
        return;
    }

    QString user = parts[1];
    int restId = parts[2].toInt();
    QStringList itemTokens = parts[3].split(",");

    if (itemTokens.isEmpty()) {
        socket->write("❌ ADD_ORDER|No items\n");
        return;
    }

    ServerOrder newOrder(OrderManager::instance().generateNewId(), user);

    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("SELECT id, name, description, price FROM menu WHERE restaurant_id = ?");
    query.addBindValue(restId);
    query.exec();

    QList<Food> menu;
    while (query.next()) {
        menu.append(Food(query.value(0).toInt(), query.value(1).toString(),
                         query.value(2).toString(), query.value(3).toDouble(),
                         FoodCategory::FAST_FOOD, ""));
    }

    for (const QString& token : itemTokens) {
        QStringList pair = token.split(":");
        if (pair.size() != 2) continue;

        QString foodName = pair[0];
        int qty = pair[1].toInt();

        for (const Food& f : menu) {
            if (f.getName() == foodName) {
                newOrder.addItem(f, qty);
                break;
            }
        }
    }

    OrderManager::instance().addOrder(newOrder);
    socket->write("✅ ADD_ORDER|Order registered\n");
}

void ClientHandler::handleGetOrders(const QStringList& parts)
{
    if (parts.size() < 2) {
        socket->write("❌ GET_ORDERS|Missing username\n");
        return;
    }

    QString username = parts[1];
    const QVector<ServerOrder> orders = OrderManager::instance().getOrdersForCustomer(username);
    if (orders.isEmpty()) {
        socket->write("ORDERS|No orders found\n");
        return;
    }

    QStringList list;
    for (const ServerOrder& order : orders) {
        QStringList itemsStr;
        for (const auto& pair : order.getItems())
            itemsStr << QString("%1×%2").arg(pair.first.getName()).arg(pair.second);

        list << QString("🧾 Order #%1 - Total: %2 - [%3]")
                    .arg(order.getId())
                    .arg(order.getTotalAmount())
                    .arg(itemsStr.join(", "));
    }

    socket->write(("ORDERS|" + list.join(";") + "\n").toUtf8());
}

void ClientHandler::handleGetOrdersByRestaurant(const QStringList& parts)
{
    // این تابع به شرطی درست کار می‌کند که در آینده یک رابطه بین غذا و رستوران در OrderManager نگهداری شود.
    socket->write("GET_ORDERS_BY_RESTAURANT|Not Implemented Yet\n");
}

void ClientHandler::handleUpdateOrderStatus(const QStringList& parts)
{
    if (parts.size() < 3) {
        socket->write("❌ UPDATE_ORDER_STATUS|Missing fields\n");
        return;
    }

    int orderId = parts[1].toInt();
    QString statusStr = parts[2].toUpper().trimmed();

    OrderStatus status;
    if (statusStr == "PENDING") status = OrderStatus::PENDING;
    else if (statusStr == "PREPARING") status = OrderStatus::PREPARING;
    else if (statusStr == "READY") status = OrderStatus::READY;
    else if (statusStr == "DELIVERED") status = OrderStatus::DELIVERED;
    else if (statusStr == "CANCELLED") status = OrderStatus::CANCELLED;
    else {
        socket->write("❌ UPDATE_ORDER_STATUS|Invalid status\n");
        return;
    }

    ServerOrder* order = OrderManager::instance().getOrderById(orderId);
    if (!order) {
        socket->write("❌ UPDATE_ORDER_STATUS|Order not found\n");
        return;
    }

    order->setStatus(status);
    socket->write("✅ UPDATE_ORDER_STATUS|Updated successfully\n");
}



void ClientHandler::handleGetRestaurants()
{
    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("SELECT id, name FROM restaurants");
    if (!query.exec()) {
        socket->write("❌ GET_RESTAURANTS|DB_ERROR\n");
        return;
    }

    QStringList items;
    while (query.next()) {
        int id = query.value(0).toInt();
        QString name = query.value(1).toString();
        items << QString("%1~%2").arg(id).arg(name);
    }

    socket->write(("RESTAURANTS|" + items.join("|") + "\n").toUtf8());
}
