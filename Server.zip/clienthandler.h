#ifndef CLIENTHANDLER_H
#define CLIENTHANDLER_H

#include <QThread>
#include <QTcpSocket>
#include <QStringList>

class ClientHandler : public QThread
{
    Q_OBJECT

public:
    explicit ClientHandler(QTcpSocket* socket, QObject* parent = nullptr);
    void run() override;

private:
    QTcpSocket* socket;
    QString username;
     void handleGetRestaurants();
    void processMessage(const QString& msg);
    void handleLogin(const QStringList& parts);
    void handleGetMenu(const QStringList& parts);
    void handleAddOrder(const QStringList& parts);
    void handleGetOrders(const QStringList& parts);
    void handleUpdateOrderStatus(const QStringList& parts);
    void handleGetOrdersByRestaurant(const QStringList& parts);
};

#endif // CLIENTHANDLER_H

