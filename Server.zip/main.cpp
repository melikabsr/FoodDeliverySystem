// #include <QCoreApplication>
// #include "ServerApp.h"
// #include "DatabaseManager.h"

// int main(int argc, char *argv[])
// {
//     QCoreApplication app(argc, argv);
//     DatabaseManager::instance().openDatabase();
//     DatabaseManager::instance().setupTables();

//     ServerApp server;
//     server.startServer(1234);
//     return app.exec();
// }


#include <QCoreApplication>
#include "ServerApp.h"
#include "DatabaseManager.h"
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    // اتصال به پایگاه‌داده
    QString databaseName = "food.db";  // ✅ اسم دیتابیس
    if (!DatabaseManager::instance().openDatabase(databaseName)) {
        qCritical() << "❌ Failed to open database.";
        return -1;
    }

    // ایجاد جدول‌ها (در صورت نیاز)
    if (!DatabaseManager::instance().setupTables()) {
        qCritical() << "❌ Failed to setup database tables.";
        return -2;
    }

    // راه‌اندازی سرور
    ServerApp server;
    if (!server.startServer(1234)) {
        qCritical() << "❌ Failed to start server on port 1234.";
        return -3;
    }

    qDebug() << "✅ Server started successfully on port 1234.";
    return app.exec();
}
