#include "DatabaseManager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

DatabaseManager::DatabaseManager(QObject* parent)
    : QObject(parent)
{}

DatabaseManager& DatabaseManager::instance()
{
    static DatabaseManager instance;
    return instance;
}

bool DatabaseManager::openDatabase(const QString& dbName)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbName);

    if (!db.open()) {
        qWarning() << "❌ Cannot open database:" << db.lastError().text();
        return false;
    }

    qDebug() << "✅ Database opened successfully.";
    return true;
}

QSqlDatabase DatabaseManager::getDatabase() const
{
    return db;
}

bool DatabaseManager::setupTables()
{
    QSqlQuery query;
    bool success = true;

    query.exec("DROP TABLE IF EXISTS users");

    success &= query.exec(
        "CREATE TABLE users ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "username TEXT, "
        "password TEXT, "
        "role TEXT, "
        "restaurant_id INTEGER DEFAULT -1)");

    success &= query.exec("CREATE TABLE IF NOT EXISTS restaurants ("
                          "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                          "name TEXT, "
                          "owner_username TEXT)");

    success &= query.exec("CREATE TABLE IF NOT EXISTS foods ("
                          "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                          "name TEXT, "
                          "description TEXT, "
                          "price REAL, "
                          "restaurant_id INTEGER)");

    return success;
}

bool DatabaseManager::validateLogin(const QString& username, const QString& password)
{
    return userRepository.validateLogin(username, password);
}

int DatabaseManager::getRestaurantId(const QString& username)
{
    QSqlQuery query;
    query.prepare("SELECT id FROM restaurants WHERE owner_username=?");
    query.addBindValue(username);
    if (query.exec() && query.next()) {
        return query.value(0).toInt();
    }
    return -1;
}
