#include "RestaurantRepository.h"
#include "DatabaseManager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QDebug>

RestaurantRepository::RestaurantRepository(QObject* parent)
    : QObject(parent) {}

RestaurantRepository& RestaurantRepository::instance()
{
    static RestaurantRepository repo;
    return repo;
}

bool RestaurantRepository::addRestaurant(const Restaurant& r)
{
    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("INSERT INTO restaurants (name, address) VALUES (?, ?)");
    query.addBindValue(r.getName());
    query.addBindValue(r.getAddress());
    if (!query.exec()) {
        qDebug() << "Add restaurant failed:" << query.lastError().text();
        return false;
    }
    return true;
}

QVector<Restaurant> RestaurantRepository::getAllRestaurants()
{
    QVector<Restaurant> list;
    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("SELECT id, name, address FROM restaurants");
    if (query.exec()) {
        while (query.next()) {
            int id = query.value(0).toInt();
            QString name = query.value(1).toString();
            QString address = query.value(2).toString();
            list.append(Restaurant(id, name, address));
        }
    } else {
        qDebug() << "Get all restaurants failed:" << query.lastError().text();
    }
    return list;
}

Restaurant RestaurantRepository::getRestaurantById(int id)
{
    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("SELECT name, address FROM restaurants WHERE id = ?");
    query.addBindValue(id);
    if (query.exec() && query.next()) {
        QString name = query.value(0).toString();
        QString address = query.value(1).toString();
        return Restaurant(id, name, address);
    }
    return Restaurant(); // Invalid
}

bool RestaurantRepository::removeRestaurant(int id)
{
    QSqlQuery query(DatabaseManager::instance().getDatabase());
    query.prepare("DELETE FROM restaurants WHERE id = ?");
    query.addBindValue(id);
    return query.exec();
}
