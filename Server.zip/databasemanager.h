#ifndef DATABASEMANAGER
#define DATABASEMANAGER
#include <QObject>
#include <QSqlDatabase>
#include "UserRepository.h"

class DatabaseManager : public QObject
{
    Q_OBJECT
public:
    static DatabaseManager& instance();
    bool openDatabase(const QString& dbName);
    bool setupTables();
    QSqlDatabase getDatabase() const;

    bool validateLogin(const QString& username, const QString& password);
    int getRestaurantId(const QString& username);
    UserRepository userRepository;

private:
    explicit DatabaseManager(QObject* parent = nullptr);
    QSqlDatabase db;
};
#endif
